import React from 'react';
import { format } from "date-fns";
import { Reply, Smile, Star, Upload, FileText, Video, Play, Pause, Clock, Check, CheckCheck, Trash, Forward, Copy, RotateCcw, Download } from "lucide-react";
import { cn } from "@/lib/utils";

// --- Improved ChatMessage Interface --- 
interface ChatMessage {
  id: string;
  sender_id: string; // Corrected from user_id
  recipient_id?: string;
  group_id?: string;
  content: string | null;
  reply_to_id?: string | null;
  file_url?: string | null;
  file_type?: 'image' | 'video' | 'file' | 'voice' | 'contact' | 'location' | null;
  file_name?: string | null;
  is_read?: boolean;
  created_at: string;
  profiles?: {
    id: string;
    display_name: string | null;
    avatar_url: string | null;
  } | null;
  // Details of the message being replied to
  replied_message?: {
    content: string;
    profiles: {
      display_name: string | null;
    } | null;
  } | null;
  is_starred?: boolean;
  deleted_for_all?: boolean;
  forwarded?: boolean;
  // Add other fields like poll_id, edited_at, disappear_at etc. if needed
}

interface ChatBubbleProps {
  message: ChatMessage;
  isOwn: boolean;
  onReply: (message: ChatMessage) => void;
  onStar: (message: ChatMessage) => void;
  onForward: (message: ChatMessage) => void;
  onCopy: (message: ChatMessage) => void;
  onDelete: (message: ChatMessage) => void;
  onPlayPauseVoiceNote?: (message: ChatMessage) => void;
  isVoiceNotePlaying?: boolean; // To control play/pause button state
}

// --- Helper to format time --- 
function formatMessageTime(iso: string): string {
  return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

// --- Chat Bubble Component --- 
export const ChatBubble = ({ 
  message, 
  isOwn, 
  onReply, 
  onStar, 
  onForward, 
  onCopy, 
  onDelete, 
  onPlayPauseVoiceNote, 
  isVoiceNotePlaying
}: ChatBubbleProps) => {
  
  const handleQuickAction = (action: 'reply' | 'star' | 'forward' | 'copy' | 'delete') => {
    switch (action) {
      case 'reply': onReply(message); break;
      case 'star': onStar(message); break;
      case 'forward': onForward(message); break;
      case 'copy': onCopy(message); break;
      case 'delete': onDelete(message); break;
      default: break;
    }
  };

  // --- Render Attachment --- 
  const renderAttachment = (msg: ChatMessage) => {
    if (!msg.file_url) return null;

    switch (msg.file_type) {
      case 'image':
        return (
          <img 
            src={msg.file_url} 
            alt={msg.file_name || 'Image attachment'} 
            className="max-w-xs max-h-64 rounded-lg cursor-pointer object-cover"
            onClick={() => window.open(msg.file_url!, '_blank')}
          />
        );
      case 'video':
        return (
         <div className="relative max-w-xs max-h-64 rounded-lg overflow-hidden cursor-pointer ">
           <video 
             src={msg.file_url} 
             controls 
             className="w-full h-full"
           /> 
         </div>
        );
      case 'voice':
        return (
          <div className="flex items-center gap-2 bg-white/10 p-2 rounded-md min-w-[200px]">
            <button 
               onClick={() => onPlayPauseVoiceNote?.(msg)}
               className="p-1.5 bg-white/20 hover:bg-white/30 rounded-full text-white/80 transition-colors"
            >
              {isVoiceNotePlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            </button>
            <span className="text-sm text-white/80">Voice Note</span>
            <Clock className="h-4 w-4 text-white/60 ml-auto" />
          </div>
        );
      case 'contact':
        // TODO: Render Contact Card
        return (
           <div className="bg-white/10 p-2 rounded-md cursor-pointer hover:bg-white/20 flex items-center gap-2">
             <User className="h-5 w-5 text-blue-300" />
             <p className="text-sm font-medium text-blue-200 truncate">Contact Card</p>
           </div>
        );
      case 'location': 
        // TODO: Render Location Preview
        return (
           <div className="bg-white/10 p-2 rounded-md cursor-pointer hover:bg-white/20">
             <MapPin className="h-5 w-5 text-blue-300 inline-block mr-1" />
             <p className="text-sm font-medium text-blue-200 inline-block">Location</p>
           </div>
        );
      case 'file':
      default:
        return (
          <a 
            href={msg.file_url} 
            download={msg.file_name}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 bg-white/10 p-2 rounded-md max-w-[250px]">
            <FileText className="h-6 w-6 text-blue-300 shrink-0" />
            <div className="min-w-0">
              <p className="truncate font-medium text-blue-200 text-sm">{msg.file_name || 'Document'}</p>
              <p className="text-xs text-blue-400">{msg.file_type === 'file' ? 'File' : 'Unknown type'}</p>
            </div>
            <Download className="h-4 w-4 text-blue-300 shrink-0" />
          </a>
        );
    }
  };

  // Render function for message content
  const renderMessageContent = (msg: ChatMessage) => {
    if (msg.deleted_for_all) {
      return <span className="italic text-sm text-gray-400">This message was deleted.</span>;
    }
    
    return (
      <div className="pr-8">
        {msg.content ? (
          <p className="text-sm leading-relaxed">
            {msg.content}
          </p>
        ) : (
          !msg.file_url && <span className="text-sm opacity-70">[Empty message]</span>
        )}
        {msg.file_url && renderAttachment(msg)}
      </div>
    );
  };

  // Check if the message is a reply context
  const isReplyContext = message.replied_message !== undefined && message.replied_message !== null;

  return (
    <div className={cn("flex flex-col group", isOwn ? "items-end" : "items-start")}>
      <div className={cn(
        "max-w-[85%] relative rounded-xl px-3 py-3 shadow-sm",
        isOwn 
          ? "bg-primary text-primary-foreground rounded-br-none"
          : "bg-card border border-border text-foreground rounded-bl-none border-opacity-70"
      )}>
        
        {/* Reply Context (WhatsApp Style) */}
        {isReplyContext && (
          <div className="mb-2 p-2 bg-black/5 dark:bg-white/5 rounded-lg border-l-4 border-primary/40 text-xs cursor-pointer hover:bg-black/10 dark:hover:bg-white/10"
             onClick={() => onReply(message)} // Scroll to the original message
          >
            <p className="font-bold opacity-80">{message.replied_message?.profiles?.display_name}</p>
            <p className="truncate italic opacity-70">{message.replied_message?.content || "[Attachment]"}</p>
          </div>
        )}

        {!isOwn && message.profiles && (
          <p className="text-[10px] font-bold text-primary mb-1 uppercase tracking-wider">
            {message.profiles.display_name}
          </p>
        )}
        
        {/* Message Content & Attachments */}
        {renderMessageContent(message)}

        {/* Timestamp and Read Receipts */}
        <div className="flex items-center justify-end gap-1.5 mt-2 mr-1 ml-auto">
           <span className="text-[10px] opacity-70 select-none">
             {formatMessageTime(message.created_at)}
           </span>
           {isOwn && (
             message.read_at ? (
                <CheckCheck className="h-3.5 w-3.5 text-primary" /> // Double tick (read)
             ) : (
                <Check className="h-3.5 w-3.5 text-primary " /> // Single tick (sent)
             )
           )}
        </div>

        {/* Quick Actions on Hover */}
        <div className={cn(
          "absolute top-1/2 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 ease-out flex gap-1 bg-card/50 border border-border backdrop-blur-sm rounded-full p-1.5",
          isOwn ? "-left-12 -translate-y-1/2" : "-right-12 -translate-y-1/2"
        )}>
          <button onClick={() => handleQuickAction('reply')} title="Reply" className="p-1.5 hover:bg-gray-700 rounded-full text-gray-300 transition-colors">
            <Reply className="h-4 w-4" />
          </button>
          <button onClick={() => handleQuickAction('star')} title="Star" className="p-1.5 hover:bg-yellow-500/20 rounded-full text-yellow-400 transition-colors">
            <Star className={`h-4 w-4 ${message.is_starred ? 'fill-current' : ''}`} />
          </button>
          <button onClick={() => handleQuickAction('forward')} title="Forward" className="p-1.5 hover:bg-blue-500/20 rounded-full text-blue-400 transition-colors">
            <Forward className="h-4 w-4" />
          </button>
          <button onClick={() => handleQuickAction('copy')} title="Copy" className="p-1.5 hover:bg-gray-700 rounded-full text-gray-300 transition-colors">
            <Copy className="h-4 w-4" />
          </button>
           <button onClick={() => handleQuickAction('delete')} title="Delete" className="p-1.5 hover:bg-red-500/20 rounded-full text-red-400 transition-colors">
             <Trash className="h-4 w-4" />
           </button>
        </div>
      </div>
    </div>
  );
};
