import React from 'react';
import { cn } from "@/lib/utils";

interface DateDividerProps {
  date: string;
  className?: string;
}

// Helper to format date for display
function formatDateForDivider(iso: string): string {
  const date = new Date(iso);
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);

  const diffTime = Math.abs(today.getTime() - date.getTime());
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays === 0) return "Today";
  if (diffDays === 1) return "Yesterday";
  
  // For dates older than yesterday, show locale date string
  return date.toLocaleDateString(undefined, {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export const DateDivider = ({ date, className }: DateDividerProps) => {
  const formattedDate = formatDateForDivider(date);

  return (
    <div className={cn("relative my-4", className)}
    >
      <div className="absolute inset-0 flex items-center">
        <span className="w-full border-t border-white/30"></span>
      </div>
      <div className="relative flex justify-center">
        <span className="bg-white/10 backdrop-blur-md px-3 py-1 rounded-full text-xs text-white/70 ">
          {formattedDate}
        </span>
      </div>
    </div>
  );
};
