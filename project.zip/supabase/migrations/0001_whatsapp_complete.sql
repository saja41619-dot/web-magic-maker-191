-- Create calls table
CREATE TABLE IF NOT EXISTS calls (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  caller_id uuid NOT NULL REFERENCES profiles(id),
  callee_id uuid REFERENCES profiles(id), -- Can be null for group calls
  group_id uuid REFERENCES chat_groups(id),
  kind TEXT NOT NULL CHECK (kind IN ('dm', 'group')),
  media TEXT NOT NULL CHECK (media IN ('voice', 'video')),
  status TEXT NOT NULL CHECK (status IN ('ringing', 'active', 'ended', 'missed')),
  started_at TIMESTAMPTZ,
  ended_at TIMESTAMPTZ
);

-- Create broadcast_lists table
CREATE TABLE IF NOT EXISTS broadcast_lists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id),
  name TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create broadcast_list_members table
CREATE TABLE IF NOT EXISTS broadcast_list_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  broadcast_list_id uuid NOT NULL REFERENCES broadcast_lists(id),
  user_id uuid NOT NULL REFERENCES profiles(id),
  UNIQUE (broadcast_list_id, user_id)
);

-- Add poll-related columns to direct_messages table (assuming direct_messages is your DM table)
ALTER TABLE direct_messages
ADD COLUMN IF NOT EXISTS poll_id uuid REFERENCES polls(id);

-- Add poll-related columns to group_messages table (assuming group_messages is your group message table)
ALTER TABLE group_messages
ADD COLUMN IF NOT EXISTS poll_id uuid REFERENCES polls(id);

-- Create polls table
CREATE TABLE IF NOT EXISTS polls (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create poll_options table
CREATE TABLE IF NOT EXISTS poll_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  poll_id uuid NOT NULL REFERENCES polls(id),
  option_text TEXT NOT NULL
);

-- Create poll_votes table
CREATE TABLE IF NOT EXISTS poll_votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  poll_option_id uuid NOT NULL REFERENCES poll_options(id),
  user_id uuid NOT NULL REFERENCES profiles(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE (poll_option_id, user_id)
);

-- Link chat groups to communities
ALTER TABLE chat_groups
ADD COLUMN IF NOT EXISTS community_id uuid REFERENCES communities(id);

-- Create communities table
CREATE TABLE IF NOT EXISTS communities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Create community_members table
CREATE TABLE IF NOT EXISTS community_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  community_id uuid NOT NULL REFERENCES communities(id),
  user_id uuid NOT NULL REFERENCES profiles(id),
  role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('member', 'admin')),
  UNIQUE (community_id, user_id)
);