import { useEffect, useMemo, useRef, useState } from "react";
import {
  Loader2,
  Send,
  Smile,
  Paperclip,
  Image as ImageIcon,
  Mic,
  Square,
  Search,
  ArrowLeft,
  Check,
  CheckCheck,
  X,
  FileText,
  Play,
  Pause,
  MoreVertical,
  Trash2,
  Copy,
  Reply,
  Info,
  Clock,
  Star,
  Forward,
  Image as ImageCardIcon,
  Phone,
  VideoIcon,
  Edit,
  Ban,
  Flag,
  Pin,
  Timer,
  Volume2,
  ChevronDown,
  MessageSquare,
  Users,
  Archive,
  BellOff,
  Palette,
  VolumeX,
  Sparkles,
  Camera,
  MapPin,
  Scan,
  UploadCloud,
  User,
  UserPlus,
  Lock,
  Voicemail,
  Link as LinkIcon,
  Video,
  VideoOff,
  MicOff,
  Disc,
  CameraOff,
} from "lucide-react";
import EmojiPicker, { Theme } from "emoji-picker-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { usePresenceHeartbeat } from "@/lib/usePresence";
import { CallManager, CallState, CallType } from "@/lib/callManager";
import { CallUI } from "@/components/CallUI";
import { cn } from "@/lib/utils";
import { NewGroupModal } from "./NewGroupModal";
import { StatusBar } from "./StatusBar";
import { WhatsAppFeaturesHub } from "./WhatsAppFeaturesHub";
import { ChatBubble } from "./ChatBubble";
import { DateDivider } from "./DateDivider"; // Assuming this will be created

import {
  loadChatSettings,
  upsertChatSetting,
  loadReactions,
  toggleReaction as dbToggleReaction,
  loadStars,
  toggleStar as dbToggleStar,
  expiresAtFromSeconds,
  WALLPAPERS,
  DISAPPEARING_OPTIONS,
  type ChatSetting,
  type Reaction,
} from "@/lib/chatFeatures";

// --- Data Interfaces --- 
interface Profile {
  id: string;
  display_name: string | null;
  avatar_url: string | null;
}

interface DM {
  id: string;
  sender_id: string;
  recipient_id: string;
  content: string | null;
  attachment_url: string | null;
  attachment_type: "image" | "file" | "voice" | "video" | "contact" | "location" | null;
  attachment_name: string | null;
  created_at: string;
  read_at: string | null;
  reply_to_id?: string | null;
  is_pinned?: boolean;
  is_starred?: boolean;
  edited_at?: string | null;
  disappear_at?: string | null;
  deleted_for_all?: boolean;
  forwarded?: boolean;
  poll_id?: string | null;
  // Replied message details for display
  replied_message?: {
    content: string;
    profiles: {
      display_name: string | null;
    } | null;
  } | null;
}

interface ChatGroup {
  id: string;
  name: string;
  avatar_url: string | null;
  created_at: string;
  created_by: string;
}

interface Presence {
  user_id: string;
  is_online: boolean;
  last_seen_at: string;
}

// --- Constants --- 
const TYPING_CHANNEL = (a: string, b: string) => `typing:${[a, b].sort().join(":")}`;

const QUICK_REACTIONS = ["👍", "❤️", "😂", "😮", "😢", "🙏"];

// --- Component --- 
export function ConnectTab() {
  usePresenceHeartbeat();
  const { user } = useAuth();
  const [users, setUsers] = useState<Profile[]>([]);
  const [presence, setPresence] = useState<Record<string, Presence>>({});
  const [groups, setGroups] = useState<ChatGroup[]>([]);
  const [lastMessages, setLastMessages] = useState<Record<string, DM>>({});
  const [unread, setUnread] = useState<Record<string, number>>({});
  const [search, setSearch] = useState("");
  const [activePeer, setActivePeer] = useState<Profile | null>(null);
  const [activeGroup, setActiveGroup] = useState<ChatGroup | null>(null);
  const [showNewGroupModal, setShowNewGroupModal] = useState(false);
  const [showFeaturesHub, setShowFeaturesHub] = useState(false);
  const [loading, setLoading] = useState(true);

  const [chatSettings, setChatSettings] = useState<Record<string, ChatSetting>>({});
  const [showArchived, setShowArchived] = useState(false);

  // Chat State & UI State
  const [messageInput, setMessageInput] = useState("");
  const [isEmojiPickerOpen, setIsEmojiPickerOpen] = useState(false);
  const [typingStatus, setTypingStatus] = useState("");
  const [incomingCall, setIncomingCall] = useState<any>(null); // Handle incoming call details
  const [currentCall, setCurrentCall] = useState<CallState | null>(null);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [remoteStream, setRemoteStream] = useState<MediaStream | null>(null);
  const [callType, setCallType] = useState<CallType | undefined>(undefined);
  const [callPeerName, setCallPeerName] = useState(""); // For the UI
  const [callDuration, setCallDuration] = useState(0);
  const callTimerRef = useRef<number | null>(null);
  const webrtcRef = useRef<CallManager | null>(null);

  const settingFor = (kind: "dm" | "group", key: string) => chatSettings[`${kind}:${key}`];

  const reloadSettings = async () => {
    if (!user) return;
    const map = await loadChatSettings(user.id);
    setChatSettings(map);
  };

  const updateSetting = async (
    kind: "dm" | "group",
    key: string,
    patch: Partial<Omit<ChatSetting, "chat_kind" | "chat_key">>, // Ensure these are the correct selectable fields
  ) => {
    if (!user) return;
    await upsertChatSetting(user.id, kind, key, patch);
    await reloadSettings();
  };

  // --- Data Loading --- 
  const loadData = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const { data: profiles } = await supabase.from("profiles").select("*, "+
            "user_presence(*)" // join presence data
            ).neq("id", user.id);
      const { data: pres } = await supabase.from("user_presence").select("*");
      const { data: grps, error: grpErr } = await supabase.from("chat_groups").select("*,"+
            "group_members(user_id)" // join members for initial group list
            );

      if (grpErr) {
        console.error("Error loading groups:", grpErr);
      }

      setUsers(profiles ?? []);
      const pmap: Record<string, Presence> = {};
      (pres ?? []).forEach((p: any) => {
        pmap[p.user_id] = p;
      });
      setPresence(pmap);

      if (grps) {
        setGroups(grps as unknown as ChatGroup[]);
      }

      await reloadSettings();
      setLoading(false);
    } catch (err) {
      console.error("Critical load data error:", err);
      setLoading(false);
    }
  };

  // --- Effects --- 
  // Load users + presence + summaries
  useEffect(() => {
    void loadData();
  }, [user]);

  // Initialize WebRTC manager
  useEffect(() => {
    if (user) {
      webrtcRef.current = new CallManager(user.id, {
        onReceiveCall: (call) => setIncomingCall(call),
        onCallStateChange: (state) => {
          if (state.state === 'active') {
            setCallDuration(0);
            if (callTimerRef.current) clearInterval(callTimerRef.current);
            callTimerRef.current = setInterval(() => {
              setCallDuration(d => d + 1);
            }, 1000);
          } else if (state.state === 'ended' || state.state === 'missed') {
            if (callTimerRef.current) clearInterval(callTimerRef.current);
            setCurrentCall(null);
            setLocalStream(null);
            setRemoteStream(null);
            // TODO: Show call ended state briefly
          }
          setCurrentCall(state);
        },
        onStreamUpdate: (stream) => setRemoteStream(stream),
      });
    }
    return () => {
      webrtcRef.current?.destroy();
      if (callTimerRef.current) clearInterval(callTimerRef.current);
    };
  }, [user]);

  // Realtime: presence + new messages -> refresh summaries
  useEffect(() => {
    if (!user) return;
    let msgSub: any;
    let presenceSub: any;
    let callSub: any;

    const setupSubscriptions = async () => {
      // Presence subscription
      presenceSub = supabase
        .channel(`presence_${user.id}`)
        .on(
          "postgres_changes",
          { event: "UPDATE", schema: "public", table: "user_presence", filter: "user_id=neq." + user.id },
          (payload: any) => {
            const updatedPresence = payload.new as Presence;
            setPresence((prev) => ({ ...prev, [updatedPresence.user_id]: updatedPresence }));
          }
        )
        .subscribe();

      // New messages subscription (DM + Group)
      const channel = supabase.channel("chat-realtime");
      channel.on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "direct_messages", filter: "recipient_id.eq." + user.id },
        (payload: any) => {
          const msg = payload.new as DM;
          // Update last message and unread count for the sender
          setLastMessages((prev) => ({ ...prev, [msg.sender_id]: msg }));
          setUnread((prev) => ({ ...prev, [msg.sender_id]: (prev[msg.sender_id] || 0) + 1 }));
          // Fetch replied message content if necessary
          if (msg.reply_to_id) {
            void fetchRepliedMessage(msg.reply_to_id).then(replied => {
              if (replied) {
                // Update state, potentially requires merging results
              }
            });
          }
        }
      );
      // Group messages subscription needs careful filtering or channel per group
      channel.on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "group_messages" }, // Subscribe broadly and filter
        async (payload: any) => {
            const msg = payload.new as any;
            // Check if user is a member of this group
            const isMember = await checkGroupMembership(user.id, msg.group_id);
            if (isMember) {
              if (activeGroup && msg.group_id === activeGroup.id) {
                // Fetch new messages for the active group
                void fetchMessages(undefined, activeGroup.id);
              }
              // Update last message and unread count for the group
              setLastMessages(prev => ({ ...prev, [`group:${msg.group_id}`]: msg }));
              setUnread(prev => ({ ...prev, [`group:${msg.group_id}`]: (prev[`group:${msg.group_id}`] || 0) + 1 }));
            }
        }
      );

      // Subscribe to call events
      callSub = supabase.channel(`call_events:${user.id}`)
        .on('broadcast', { event: 'incoming_call' }, ({ payload }) => {
          console.log('Incoming call detected:', payload);
          setIncomingCall(payload);
        })
        .subscribe();

      msgSub = channel;
    };

    void setupSubscriptions();

    return () => {
      if (msgSub) void supabase.removeChannel(msgSub);
      if (presenceSub) void supabase.removeChannel(presenceSub);
      if (callSub) void supabase.removeChannel(callSub);
    };
  }, [user]); // Removed activeGroup from dependency to avoid re-subscribing constantly

  // --- Message Handling --- 
  const [messages, setMessages] = useState<DM[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messageInputRef = useRef<HTMLTextAreaElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const fetchRepliedMessage = async (messageId: string) => {
    // Fetch from direct_messages table first
    let { data: dmData, error: dmError } = await supabase
      .from("direct_messages")
      .select("*, sender:sender_id(display_name)")
      .eq("id", messageId)
      .maybeSingle();

    // If not found in direct_messages, try group_messages
    if (!dmData && !dmError) {
      let { data: groupData, error: groupError } = await supabase
        .from("group_messages")
        .select("*, sender:sender_id(display_name)")
        .eq("id", messageId)
        .maybeSingle();
      
      if (groupData) {
        dmData = groupData; // Use group data if found
      }
    }

    if (dmError && dmData === null) { // Check specifically for errors if data is null
       console.warn("Error fetching direct_message for reply:", dmError);
    }
    if (dmData === null) { // If still not found, log a warning about group message query
        console.warn("Message not found in direct_messages, trying group_messages...");
    }

    if (!dmData) {
       console.error("Failed to fetch replied message for ID:", messageId);
       return null;
    }

    return {
      content: dmData.content,
      profiles: {
        display_name: dmData.sender?.display_name || "Unknown Sender",
      },
    };
  };

  const fetchMessages = async (targetUserId?: string, groupId?: string, page = 0) => {
    if (!user) return;
    setLoadingMessages(true);
    try {
      const messagesPerPage = 50;
      let query = supabase
        .from(targetUserId ? "direct_messages" : "group_messages")
        .select(
          "id, sender_id, recipient_id, group_id, content, attachment_url, attachment_type, attachment_name, created_at, read_at, reply_to_id, is_starred, forwarded, poll_id, sender:sender_id(id, display_name, avatar_url)"
        )
        .limit(messagesPerPage)
        .range(page * messagesPerPage, (page + 1) * messagesPerPage - 1)
        .order("created_at", { ascending: false });

      if (targetUserId) {
        query = query.or(`recipient_id.eq.${targetUserId},sender_id.eq.${targetUserId}`);
      } else if (groupId) {
        query = query.eq("group_id", groupId);
      } else {
        setLoadingMessages(false);
        return;
      }

      const { data, error } = await query;

      if (error) throw error;

      const fetchedMessagesWithDetails = await Promise.all(
        (data || []).map(async (msg: any) => {
          const repliedMsgDetails = msg.reply_to_id ? await fetchRepliedMessage(msg.reply_to_id) : null;
          return {
              ...msg,
              profiles: msg.sender, // Map sender to profiles for ChatBubble compatibility
              replied_message: repliedMsgDetails,
              sender_profile: msg.sender, // Duplicate for clarity
          } as DM;
        })
      );

      setMessages(fetchedMessagesWithDetails.reverse()); // Reverse to show chronological order
      scrollToBottom();

      // Mark messages as read if they are from the other user and not read yet
      if (targetUserId && !isOwn(targetUserId)) {
        const unreadIds = fetchedMessagesWithDetails
          .filter(m => m.recipient_id === user?.id && !m.read_at)
          .map(m => m.id);
        if (unreadIds.length > 0) {
          await supabase.rpc('mark_messages_read', { message_ids: unreadIds });
          setUnread((prev) => ({ ...prev, [targetUserId]: 0 }));
        }
      }

    } catch (error) {
      toast.error("Failed to load messages.");
      console.error(error);
    } finally {
      setLoadingMessages(false);
    }
  };

  // Helper to check if user is member of a group (needed for group message subscription filter)
  const checkGroupMembership = async (userId: string, groupId: string): Promise<boolean> => {
    if (!groupId) return false;
    const { count, error } = await supabase
      .from('group_members')
      .select('*', { count: 'exact', head: true })
      .eq('group_id', groupId)
      .eq('user_id', userId);
    if (error) {
      console.error("Error checking group membership:", error);
      return false;
    }
    return count !== null && count > 0;
  };

  // Effect to fetch messages when active peer or group changes
  useEffect(() => {
    if (activePeer) {
      void fetchMessages(activePeer.id);
      // Subscribe to typing indicators for this specific chat
      const typingChannel = supabase.channel(TYPING_CHANNEL(user!.id, activePeer.id));
      typingChannel.on("broadcast", { event: "is_typing" }, ({ payload }) => {
        if (payload.sender === activePeer.id) {
            setTypingStatus("typing...");
            setTimeout(() => setTypingStatus(""), 3000); // Clear after 3s
        }
      });
      typingChannel.subscribe();
      return () => { void supabase.removeChannel(typingChannel); };
    } else if (activeGroup) {
      void fetchMessages(undefined, activeGroup.id);
      // Subscribe to typing indicators for the group
      const typingChannel = supabase.channel(`typing:${activeGroup.id}`);
      typingChannel.on("broadcast", { event: "is_typing" }, ({ payload }) => {
        // Handle group typing indicators - maybe show multiple users typing or "Users are typing..."
      });
      typingChannel.subscribe();
      return () => { void supabase.removeChannel(typingChannel); };
    } else {
      setMessages([]); // Clear messages if no chat is active
    }
  }, [activePeer, activeGroup]); // Dependency array

  // Function to check if user is online
  const isOnline = (userId: string) => presence[userId]?.is_online ?? false;
  const lastSeen = (userId: string) => presence[userId]?.last_seen_at ?? "";

  const isOwn = (userId: string) => user?.id === userId;

  const sendMessage = async () => {
    if (!messageInput.trim() || !user) return;

    const content = messageInput.trim();
    setMessageInput(""); // Clear input immediately
    setIsEmojiPickerOpen(false);
    setTypingStatus(""); // Clear typing indicator

    let messageData: Partial<DM> = {
      sender_id: user.id,
      content,
      created_at: new Date().toISOString(),
    };

    // Determine recipient or group
    if (activePeer) {
      messageData.recipient_id = activePeer.id;
      // Broadcast typing status
      const typingChannel = supabase.channel(TYPING_CHANNEL(user.id, activePeer.id));
      await typingChannel.send({ type: "broadcast", event: "is_typing", payload: { sender: user.id } });
    } else if (activeGroup) {
      messageData.group_id = activeGroup.id;
      // Broadcast typing status for group (if implemented)
    } else {
      toast.error("No active chat selected.");
      return;
    }

    try {
      const { data, error } = await supabase
        .from(activePeer ? "direct_messages" : "group_messages")
        .insert([{ ...messageData }])
        .select("*, sender:sender_id(id, display_name, avatar_url), replied_to_message:reply_to_id(sender_id(display_name), content)") // Select details for replied message if available
        .single();

      if (error) throw error;
      
      const sentMessage = { 
        ...data,
        profiles: data.sender, // Map sender to profiles
        replied_message: data.replied_to_message ? { content: data.replied_to_message.content, profiles: { display_name: data.replied_to_message.sender?.display_name } } : null,
      } as DM;

      setMessages((prev) => [...prev, sentMessage]);
      scrollToBottom();

      // Update last messages and unread counts client-side
      if (activePeer) {
        setLastMessages((prev) => ({ ...prev, [activePeer.id]: sentMessage }));
        setUnread((prev) => ({ ...prev, [activePeer.id]: 0 })); // Mark as read
      } else if (activeGroup) {
        setLastMessages((prev) => ({ ...prev, [`group:${activeGroup.id}`]: sentMessage }));
        // Group unread count update is complex, might need backend logic or separate subscription
      }

    } catch (error: any) {
      console.error("Error sending message:", error);
      toast.error(error.message || "Failed to send message.");
    }
  };

  // --- Chat UI Interactions --- 
  const handleSelectChat = (user: Profile) => {
    setActivePeer(user);
    setActiveGroup(null);
    setMessages([]); // Clear previous messages
    setSearch(""); // Clear search
    setTypingStatus("");
    // Implicitly call fetchMessages via useEffect dependency
  };

  const handleSelectGroup = (group: ChatGroup) => {
    setActiveGroup(group);
    setActivePeer(null);
    setMessages([]); // Clear previous messages
    setSearch(""); // Clear search
    setTypingStatus("");
    // Implicitly call fetchMessages via useEffect dependency
  };

  const handleBack = () => {
    setActivePeer(null);
    setActiveGroup(null);
    setMessages([]);
    setSearch("");
    setTypingStatus("");
  };

  const handleReply = (message: DM) => {
    setMessageInput(`Replying to ${message.sender_profile?.display_name || ''}: `); // Prepend reply context
    messageInputRef.current?.focus();
    // Store the message ID being replied to, so it can be sent with the new message
    // This requires adding a state variable for `replyingToMessageId`
    console.log("Reply to message:", message);
  };

  const toggleEmojiPicker = () => {
    setIsEmojiPickerOpen((prev) => !prev);
    if (!isEmojiPickerOpen) {
      messageInputRef.current?.focus();
    }
  };

  const onEmojiClick = (event: any) => {
    setMessageInput((prev) => prev + event.emoji);
  };

  const handleAttachment = async (type: DM["attachment_type"], file: File) => {
    const filePath = `${user?.id}/${type}-${file.name}`;
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from("attachments") 
      .upload(filePath, file, {
        cacheControl: '3600',
        upsert: false,
      });

    if (uploadError) {
      console.error("Upload error:", uploadError);
      toast.error("Failed to upload attachment.");
      return;
    }

    const { data: publicUrlData } = supabase.storage.from("attachments").getPublicUrl(filePath);
    const attachmentUrl = publicUrlData.publicUrl;

    let messageData: Partial<DM> = {
      sender_id: user!.id,
      attachment_url: attachmentUrl,
      attachment_type: type,
      attachment_name: file.name,
      created_at: new Date().toISOString(),
    };

    if (activePeer) {
      messageData.recipient_id = activePeer.id;
    } else if (activeGroup) {
      messageData.group_id = activeGroup.id;
    }

    try {
      const { data, error } = await supabase
        .from(activePeer ? "direct_messages" : "group_messages")
        .insert([{ ...messageData }])
        .select("*, sender:sender_id(id, display_name, avatar_url)")
        .single();

      if (error) throw error;

      const sentMessage = { ...data, profiles: data.sender } as DM;
      setMessages((prev) => [...prev, sentMessage]);
      scrollToBottom();
      // Update last messages state
      if (activePeer) {
        setLastMessages((prev) => ({ ...prev, [activePeer.id]: sentMessage }));
        setUnread((prev) => ({ ...prev, [activePeer.id]: 0 }));
      } else if (activeGroup) {
        setLastMessages((prev) => ({ ...prev, [`group:${activeGroup.id}`]: sentMessage }));
      }

      toast.success("Attachment sent!");
    } catch (error: any) {
      console.error("Error sending attachment:", error);
      toast.error(error.message || "Failed to send attachment.");
    }
  };

  const handleVoiceNote = async (blob: Blob) => {
    const file = new File([blob], `voice_${Date.now()}.webm`, { type: "audio/webm" });
    await handleAttachment("voice", file);
  };

  // --- Call Handling --- 
  const startCall = async (type: CallType) => {
      if (!user) return;
      let targetUserId: string | undefined;
      let groupId: string | undefined;
      if (activePeer) {
          targetUserId = activePeer.id;
          setCallPeerName(activePeer.display_name || "User");
      } else if (activeGroup) {
          groupId = activeGroup.id;
          setCallPeerName(activeGroup.name || "Group");
      }
      if (!targetUserId && !groupId) {
          toast.error("Select a user or group to call.");
          return;
      }
      setCallType(type);
      try {
        const stream = await webrtcRef.current?.prepareCall(type, targetUserId, groupId);
        setLocalStream(stream);
        setCurrentCall({
            state: 'ringing',
            type,
            callerId: user.id,
            calleeId: targetUserId,
            groupId: groupId,
            roomId: webrtcRef.current?.roomId || 'unknown-room' // Assign a room ID
        });
        toast.info(`Calling ${type}...`);
      } catch (error) {
          console.error("Failed to start call:", error);
          toast.error("Could not start call. Please check permissions.");
      }
  };

  const acceptCall = async () => {
      if (!incomingCall) return;
      try {
          const stream = await webrtcRef.current?.acceptCall(incomingCall.roomId);
          setLocalStream(stream);
          setCallType(incomingCall.media);
          setCallPeerName(incomingCall.callerName || "User"); 
          setIncomingCall(null);
          toast.success("Call accepted.");
      } catch (error) {
          console.error("Failed to accept call:", error);
          toast.error("Could not accept call.");
      }
  };

  const declineCall = async () => {
      if (!incomingCall) return;
      await webrtcRef.current?.rejectCall(incomingCall.roomId);
      setIncomingCall(null);
      toast("Call declined.");
  };

  const endCall = async () => {
      await webrtcRef.current?.endCall();
      if (callTimerRef.current) clearInterval(callTimerRef.current);
      setCurrentCall(null);
      setLocalStream(null);
      setRemoteStream(null);
      setCallType(undefined);
  };

  const toggleMic = async (enabled: boolean) => {
      webrtcRef.current?.toggleMic(enabled);
  };

  const toggleVideo = async (enabled: boolean) => {
      webrtcRef.current?.toggleVideo(enabled);
  };

  // --- Render Logic --- 
  const chatUser = activePeer;
  const chatGroup = activeGroup;
  const chatTargetId = chatUser?.id ?? chatGroup?.id;
  const chatTargetType = chatUser ? "dm" : chatGroup ? "group" : null;

  // Filter users/groups based on search term
  const filteredChats = useMemo(() => {
    const searchTermLower = search.toLowerCase();
    
    const dmChats = users
      .filter(u => u.display_name?.toLowerCase().includes(searchTermLower))
      .map(u => ({ type: "dm", data: u } as const));

    const groupChats = groups
      .filter(g => g.name?.toLowerCase().includes(searchTermLower))
      .map(g => ({ type: "group", data: g } as const));

    return [...dmChats, ...groupChats].sort((a, b) => {
      const lastMsgA = lastMessages[a.type === 'dm' ? a.data.id : `group:${a.data.id}`];
      const lastMsgB = lastMessages[b.type === 'dm' ? b.data.id : `group:${b.data.id}`];
      if (!lastMsgA && !lastMsgB) return 0;
      if (!lastMsgA) return 1;
      if (!lastMsgB) return -1;
      return new Date(lastMsgB.created_at).getTime() - new Date(lastMsgA.created_at).getTime();
    });
  }, [search, users, groups, lastMessages]);

  const activeChatName = chatUser?.display_name ?? chatGroup?.name ?? "Select a chat";
  const activeChatAvatar = chatUser?.avatar_url ?? chatGroup?.avatar_url ?? "/default-avatar.png";

  const chatSetting = chatTargetId ? settingFor(chatUser ? "dm" : "group", chatTargetId) : null;
  const wallpaperUrl = chatSetting?.wallpaper || WALLPAPERS[0].url;
  const disappearingMessageTimeout = chatSetting?.disappear_after || DISAPPEARING_OPTIONS[0].seconds;


  return (
    <div className="relative flex h-full w-full wa wa-doodle-bg">
      {/* Left Pane: Chat List */}
      <div className="w-1/3 border-r border-white/20 bg-white/5 p-3 backdrop-blur-md flex flex-col">
        <div className="mb-3 flex items-center gap-2">
          {/* Header: Back button (mobile) or Logo */}
          <button onClick={handleBack} className="md:hidden p-2 hover:bg-white/10 rounded-full text-white/70">
            <ArrowLeft className="h-5 w-5" />
          </button>
          <h2 className="font-display text-xl font-bold text-white ml-2">Connect</h2>
          <button onClick={() => setShowFeaturesHub(true)} className="ml-auto p-2 hover:bg-white/10 rounded-full text-white/70">
            <Sparkles className="h-5 w-5" />
          </button>
        </div>
        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-white/50" />
          <input 
            type="text" 
            placeholder="Search or start new chat" 
            value={search} 
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-full bg-white/10 py-2 pl-10 pr-4 text-sm text-white outline-none focus:ring-2 focus:ring-white/50" 
          />
          {/* TODO: Add New Chat/Group button here */}
          <button onClick={() => setShowNewGroupModal(true)} className="absolute right-3 top-1/2 -translate-y-1/2 p-2 hover:bg-white/10 rounded-full text-white/70">
            <Users className="h-4 w-4" />
          </button>
        </div>

        {/* Chat List */}
        <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-white/10">
          {filteredChats.length === 0 && !loading ? (
            <p className="text-center text-sm text-white/60 mt-10">No chats found.</p>
          ) : (
            filteredChats.map(chat => {
              const isDmChat = chat.type === "dm";
              const chatData = chat.data as Profile | ChatGroup;
              const userId = isDmChat ? chatData.id : `group:${chatData.id}`;
              const lastMsg = lastMessages[userId];
              const unreadCount = unread[userId] || 0;
              const isOwner = user?.id === userId;
              const isChatActive = activePeer?.id === chatData.id || activeGroup?.id === chatData.id;

              // For DM chats, get associated profile data, otherwise use group data
              const profile = isDmChat ? (chatData as Profile) : null;
              const group = isDmChat ? null : (chatData as ChatGroup);
              
              return (
                <div
                  key={userId}
                  onClick={() => isDmChat ? handleSelectChat(profile!) : handleSelectGroup(group!)}
                  className={`flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-smooth ${isChatActive ? "bg-white/15" : "hover:bg-white/10"}`}
                >
                  <div className="relative h-12 w-12 shrink-0 overflow-hidden rounded-full bg-primary/50 text-white text-base font-bold flex items-center justify-center">
                    {profile?.avatar_url ? (
                      <img src={profile.avatar_url} alt="" className="h-full w-full object-cover" />
                    ) : group?.avatar_url ? (
                      <img src={group.avatar_url} alt="" className="h-full w-full object-cover" />
                    ) : (
                      (group?.name || profile?.display_name || "?").charAt(0).toUpperCase()
                    )}
                    {isDmChat && (!isOwner && isOnline(profile!.id)) && (
                       <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full bg-green-500 ring-2 ring-white/20"></span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-white truncate">
                        {group?.name || profile?.display_name || "Unknown"}
                    </p>
                    <p className="text-xs text-white/70 truncate">
                        {lastMsg?.content || "-"}
                    </p>
                  </div>
                  <div className="flex flex-col items-end">
                    <time className="text-xs text-white/70 mb-1">
                        {lastMsg ? new Date(lastMsg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : "-"}
                    </time>
                    {unreadCount > 0 && (
                      <span className="flex h-5 w-5 items-center justify-center rounded-full bg-green-500 text-[10px] font-bold text-white">
                        {unreadCount}
                      </span>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Middle Pane: Conversation / Right Pane: Details (conditionally shown) */} 
      <div className={`w-2/3 flex flex-col ${chatTargetId ? " " : "hidden md:flex "}`}>
        {chatTargetId ? (
          <> 
            {/* Chat Header */}
            <header className="flex items-center gap-3 border-b border-white/20 bg-white/5 p-3 backdrop-blur-md ">
              <div className="relative h-10 w-10 shrink-0 overflow-hidden rounded-full bg-primary/50 text-white text-base font-bold flex items-center justify-center">
                  {profile?.avatar_url ? (
                      <img src={profile.avatar_url} alt="" className="h-full w-full object-cover" />
                    ) : group?.avatar_url ? (
                      <img src={group.avatar_url} alt="" className="h-full w-full object-cover" />
                    ) : (
                      (group?.name || profile?.display_name || "?").charAt(0).toUpperCase()
                    )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-white">
                    {activeChatName}
                </p>
                <p className="text-xs text-white/70">
                   {chatUser && (!isOnline(chatUser.id) ? `Last seen: ${formatLastSeen(lastSeen(chatUser.id))}` : "online")}
                   {chatGroup && "" /* Group presence not shown in WA */}
                </p>
              </div>
              <div className="flex items-center gap-3 ml-auto">
                {chatUser && (
                  <>
                    <button onClick={() => startCall('voice')} className="p-2 hover:bg-white/10 rounded-full text-white/70"><Phone className="h-5 w-5" /></button>
                    <button onClick={() => startCall('video')} className="p-2 hover:bg-white/10 rounded-full text-white/70"><VideoIcon className="h-5 w-5" /></button>
                  </>
                )}
                 {/* TODO: Add group call functionality */}
                <button className="p-2 hover:bg-white/10 rounded-full text-white/70"><Search className="h-5 w-5" /></button>
                <button className="p-2 hover:bg-white/10 rounded-full text-white/70"><Info className="h-5 w-5" /></button>
                <button className="p-2 hover:bg-white/10 rounded-full text-white/70"><MoreVertical className="h-5 w-5" /></button>
              </div>
            </header>

            {/* Message List */}
            <div 
              className="relative flex-1 overflow-y-auto p-4 scrollbar-thin scrollbar-thumb-primary/30"
              style={{ backgroundImage: `url(${wallpaperUrl})`, backgroundSize: 'cover' }} 
            >
              {loadingMessages ? (
                <div className="flex h-full items-center justify-center">
                  <Loader2 className="h-6 w-6 animate-spin text-white/60" />
                </div>
              ) : messages.length === 0 ? (
                <div className="flex h-full items-center justify-center text-sm text-white/70">
                 Start the conversation!
                </div>
              ) : (
                <div className="flex flex-col gap-4">
                  {messages.map((msg, index) => {
                    const isOwnMessage = msg.sender_id === user?.id;
                    const prevMessage = index > 0 ? messages[index - 1] : null;
                    const showDateDivider = !prevMessage || new Date(msg.created_at).toLocaleDateString() !== new Date(prevMessage.created_at).toLocaleDateString();

                    // Handle voice note playing state
                    // This would typically be managed in a parent component or a context
                    // For simplicity, assume a single voice note can be 'playing'
                    const isVoiceNotePlaying = msg.attachment_type === 'voice' && false; // Replace false with actual playing state logic

                    return (
                      <React.Fragment key={msg.id}>
                        {showDateDivider && <DateDivider date={msg.created_at} />}
                        <ChatBubble 
                          message={msg} 
                          isOwn={isOwnMessage} 
                          onReply={handleReply} 
                          onStar={async (m) => {
                            await dbToggleStar(user!.id, m.id, !m.is_starred);
                            // Optimistic UI update: find message and toggle its star status
                            setMessages(prev => prev.map(msg => msg.id === m.id ? {...msg, is_starred: !m.is_starred} : msg));
                          }}
                          onForward={() => toast("Forward not implemented yet.")}
                          onCopy={async (m) => { await navigator.clipboard.writeText(m.content || ""); toast("Copied!"); }}
                          onDelete={async (m) => {
                            // Implement delete logic (soft delete for sender, hard delete for all?)
                            toast("Delete not implemented yet.");
                          }}
                          onPlayPauseVoiceNote={async (m) => {
                             // Implement voice note playback logic here
                             toast("Voice note playback not implemented yet.");
                          }}
                          isVoiceNotePlaying={isVoiceNotePlaying}
                        />
                      </React.Fragment>
                    );
                  })}
                  <div ref={messagesEndRef} />
                </div>
              )}
            </div>

            {/* Message Composer */}
            <div className="border-t border-white/20 bg-white/5 p-3 backdrop-blur-md ">
              <div className="relative flex items-center gap-3">
                {/* Emoji Picker Toggle */}
                <button onClick={toggleEmojiPicker} className="p-2 hover:bg-white/10 rounded-full text-white/70">
                  <Smile className="h-6 w-6" />
                </button>
                
                {/* Attachment Menu */}
                <div className="relative group">
                  <label htmlFor="attachment-upload" className="p-2 hover:bg-white/10 rounded-full text-white/70 cursor-pointer block">
                      <Paperclip className="h-6 w-6" />
                  </label>
                  <input
                    id="attachment-upload"
                    type="file"
                    accept="image/*,video/*,audio/*,.pdf,.doc,.docx,text/vcard"
                    className="hidden"
                    onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                           if (file.type.startsWith('image/')) {
                                handleAttachment('image', file);
                            } else if (file.type.startsWith('video/')) {
                                handleAttachment('video', file);
                            } else if (file.type.startsWith('audio/')) {
                                handleAttachment('voice', file);
                            } else if (file.type === 'text/vcard') { // Handling contact card
                                handleAttachment('contact', file);
                            } else {
                                handleAttachment('file', file);
                            }
                        }
                    }}
                  />
                  {/* TODO: Add dedicated buttons for Location, Contact */} 
                </div>

                {/* Message Input */}
                <textarea
                  ref={messageInputRef}
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      sendMessage();
                    }
                  }}
                  placeholder={`Message ${activeChatName}`} 
                  rows={1} 
                  className="flex-1 resize-none rounded-lg bg-white/10 py-2 pl-4 pr-10 text-sm text-white outline-none focus:ring-2 focus:ring-white/50 placeholder-white/50 caret-white"
                  style={{ minHeight: '40px', maxHeight: '120px', overflowY: 'auto' }}
                />

                {/* Send Button / Voice Message Toggle */}
                {messageInput.trim() ? (
                  <button onClick={sendMessage} className="absolute right-14 top-1/2 -translate-y-1/2 p-2 hover:bg-white/10 rounded-full text-white/70">
                    <Send className="h-6 w-6" />
                  </button>
                ) : (
                   <button /*onClick={toggleEmojiPicker}*/ className="absolute right-14 top-1/2 -translate-y-1/2 p-2 hover:bg-white/10 rounded-full text-white/70">
                     {/* Replace with actual voice message recording button */}
                     <Mic className="h-6 w-6" /> 
                   </button>
                )}
              </div>
              {isEmojiPickerOpen && (
                <div className="absolute bottom-full right-0 mb-2 -ml-4">
                   <EmojiPicker theme={Theme.DARK} onEmojiClick={onEmojiClick} />
                </div>
              )}
              {typingStatus && (
                 <p className="text-xs text-white/70 mt-1 ml-1">{typingStatus}</p>
              )}
            </div>
          </>
        ) : (
          // Default View when no chat is selected
          <div className="flex h-full items-center justify-center bg-white/5 text-center text-lg text-white/60 backdrop-blur-md">
             <div className="max-w-md">
               <img src="/connect-placeholder.svg" alt="Connect Placeholder" className="mx-auto mb-4 h-48 w-48 opacity-50" />
               <h3 className="font-semibold">Keep conversations in Connect</h3>
               <p className="text-sm mt-2">Chat with friends, family, and colleagues. Connect helps you share moments and stay in touch.</p>
               <button onClick={() => setShowNewGroupModal(true)} className="mt-4 px-6 py-2 border border-white/30 rounded-full text-white/80 hover:bg-white/10 transition-smooth">
                 Start a new chat
               </button>
             </div>
          </div>
        )}
      </div>

      {/* Right Pane: Chat Details / Call UI */} 
      {/* Conditionally render details pane or call UI */}
      {currentCall && (
         <CallUI 
           localStream={localStream} 
           remoteStream={remoteStream} 
           callType={currentCall.type} 
           callDuration={callDuration} 
           onEndCall={endCall} 
           onToggleMic={toggleMic} 
           onToggleVideo={toggleVideo} 
           peerName={callPeerName} 
         />
      )}
      {incomingCall && (
          <div className="fixed inset-0 z-[101] flex items-center justify-center bg-black/70 backdrop-blur-lg">
              <div className="bg-card rounded-xl p-6 shadow-elegant border border-border">
                  <h3 className="font-bold text-lg mb-2">Incoming Call from {incomingCall.callerName || 'Unknown'}</h3>
                  <p className="text-sm text-muted-foreground mb-4">{incomingCall.media === 'video' ? 'Video Call' : 'Voice Call'}</p>
                  <div className="flex gap-4 justify-center">
                      <button onClick={acceptCall} className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-full flex items-center gap-1">
                           <Phone className="h-4 w-4" /> Accept
                      </button>
                      <button onClick={declineCall} className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-full flex items-center gap-1">
                           <X className="h-4 w-4" /> Decline
                      </button>
                  </div>
              </div>
          </div>
      )}
      
      {showNewGroupModal && (
        <NewGroupModal 
          allUsers={users} 
          onClose={() => setShowNewGroupModal(false)} 
          onGroupCreated={loadData} // Reload groups after creation
        />
      )}
      {showFeaturesHub && (
        <WhatsAppFeaturesHub onClose={() => setShowFeaturesHub(false)} />
      )}
    </div>
  );
}
